
package com.ars;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
/**In this class the airline having some different kind of trip plans
*
* This is fully depends on the passenger requirements
* what ever the choice is given from the passenger it will takes.
*
*/
public class AirlineHomePage {

	public static void Booking(String id) {
		Scanner scanner = new Scanner(System.in);
		int classs = 0;
		int numpass = 0;
		double price = 0;
		String className = "";
		String airwaysName = "";
		System.out.println("===HOME PAGE===");
		//storing all airways in an array
		String airwaysList[] = { "", "British Airways", "Emirates Airline", "Turkey Airlines", "Air Canada" };
		System.out.println(
				"The airways we have : \n1.British Airways \n2.Emirates Airline \n3.Turkey Airlines.\n4.Air Canada \n5.Click 5 to view prices!");
		int airline = scanner.nextInt();
		if (airline != 5) {
			System.out.println(" ");
			//storing classes available in an array
			String classesList[] = { "", "Economy Class", "First Class", "Business Class" };
			System.out.println("Ticket classes available are : \n1.Economy Class  \n2.First Class \n3.Business Class");
			System.out.println("Choose your class ");
			classs = scanner.nextInt();
			airwaysName = airwaysList[airline];
			className = classesList[classs];
			System.out.println("Enter the number of passangers going to travel: ");
			numpass = scanner.nextInt();
			System.out.println("Your booking details ---------");
			System.out.print("Number of passangers are ");
			System.out.println(numpass);
			System.out.print("Airline you choose: ");
			System.out.println(airwaysName);
			System.out.print("Ticket class you choose: ");
			System.out.println(className);
			
		}
		switch (airline) {
		case 1:
			//this case works for British Airways
			if (numpass > 4 && classs == 1) {
				System.out.println("Total price is : " + (numpass * 100));
				price = ((numpass * 100) - (numpass * 100 * 0.1));
				System.out.println("Discounted price British Airways for you is" + price);
				System.out.println("Thank you...have a great journey!!!!");

			} else if (numpass > 4 && classs == 2) {
				System.out.println("Total price is: " + (numpass * 200));
				price = ((numpass * 200) - (numpass * 200 * 0.1));
				System.out.println("Discounted price British Airways for you is" + price);
				System.out.println("Thank you...have a great journey!!!!");
			} else if (numpass > 4 && classs == 3) {
				System.out.println("Total price is: " + (numpass * 300));
				price = ((numpass * 300) - (numpass * 300 * 0.1));
				System.out.println("Discounted price British Airways for you is" + price);
				System.out.println("Thank you...have a great journey!!!!");
			} else {
				System.out.println("Total price is: " + (numpass * 400));
				price = (numpass * 400);
				System.out.println("NO DISCOUNT IN THE PRICE ");
			}

			break;

		case 2:
			//this case works for Emirates Airways
			if (numpass > 4 && classs == 1) {
				System.out.println("Total price is : " + (numpass * 200));
				price = ((numpass * 200) - (numpass * 200 * 0.1));
				System.out.println("Discounted price Emirates Airline for you is" + price);
				System.out.println("Thank you...have a great journey!!!!");
			} else if (numpass > 4 && classs == 2) {
				System.out.println("Total price is: " + (numpass * 250));
				price = ((numpass * 250) - (numpass * 250 * 0.1));
				System.out.println("Discounted price Emirates Airline for you is" + price);
				System.out.println("Thank you...have a great journey!!!!");
			} else if (numpass > 4 && classs == 3) {
				System.out.println("Total price is: " + (numpass * 300));
				price = ((numpass * 300) - (numpass * 300 * 0.1));
				System.out.println("Discounted price Emirates Airline for you is" + price);
				System.out.println("Thank you...have a great journey!!!!");
			} else {
				System.out.println("Total price is: " + (numpass * 450));
				System.out.println("NO DISCOUNT IN THE PRICE ");
				price = (numpass * 450);
			}

			break;

		case 3:
			//this case works for Turkish Airways
			if (numpass > 4 && classs == 1) {
				System.out.println("Total price is : " + (numpass * 200));
				price = ((numpass * 200) - (numpass * 200 * 0.1));
				System.out.println("Discounted price of Turkish Airline for you is " + price);
				System.out.println("Thank you...have a great journey!!!!");
			} else if (numpass > 4 && classs == 2) {
				System.out.println("Total price is: " + (numpass * 250));
				price = ((numpass * 250) - (numpass * 250 * 0.1));
				System.out.println("Discounted price of Turkish Airline for you is " + price);
				System.out.println("Thank you...have a great journey!!!!");
			} else if (numpass > 4 && classs == 3) {
				System.out.println("Total price is: " + (numpass * 300));
				price = ((numpass * 300) - (numpass * 300 * 0.1));
				System.out.println("Discounted price of Turkish Airline for you is " + price);
				System.out.println("Thank you...have a great journey!!!!");
			} else {
				price = (numpass * 400);
				System.out.println("Total price is: " + (numpass * 400));
				System.out.println("NO DISCOUNT IN THE PRICE ");
			}

			break;
		case 4:
			//this case works for Air Canada
			if (numpass > 4 && classs == 1) {
				System.out.println("Total price is : " + (numpass * 300));
				price = ((numpass * 300) - (numpass * 300 * 0.1));
				System.out.println(" Discounted price of Air Canada for you is " + price);
				
			} else if (numpass > 4 && classs == 2) {
				System.out.println("Total price is: " + (numpass * 350));
				price = ((numpass * 350) - (numpass * 350 * 0.1));
				System.out.println(" Discounted price of Air Canada for you is " + price);
				
			} else if (numpass > 4 && classs == 3) {
				System.out.println("Total price is: " + (numpass * 400));
				price = ((numpass * 400) - (numpass * 400 * 0.1));
				System.out.println(" Discounted price of Air Canada for you is " + price);
				System.out.println("Thank you...have a great journey!!!!");
				
			} else {
				price = (numpass * 500);
				System.out.println("Total price is: " + (numpass * 500));
				System.out.println("NO DISCOUNT IN THE PRICE");
				System.out.println("Thank you...have a great journey!!!!");
			}
			break;
		case 5:
			//to list prices
			showPrices();
			break;
		default:
			System.out.println("Please choose one from the options :)");
		}
		if (airline != 5)
			storeBooking(id, airwaysName, className, price, numpass);

	}
//this method will list all the prices of each airlines
	public static void showPrices() {
		System.out.println(
				" prices of British airways are:\n1.Economy Class:100$ \n2.First Class:200$ \n3.Business Class:300$\n");
		System.out.println(
				" prices of Emirates Airline are:\n1.Economy Class:200$ \n2.First Class:250$ \n3.Business Class:300$\n");
		System.out.println(
				" prices of Turkish Airline  are:\n1.Economy Class:250$ \n2.First Class:300$ \n3.Business Class:350$\n");
		System.out.println(
				" prices of Air Canada are:\n1.Economy Class:300$ \n2.First Class:350$ \n3.Business Class:400$\n");
	}
//this method will be used to store booking details to database
	public static void storeBooking(String id, String airline, String classs, double price, int numpass) {
		try {
			//jdbc connection
			Connection conn = DatabaseConnections.getConnection();
			
			String query = "insert into Bookings(id,airline,classs,price,passengersCount)" + "values(?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, id);
			ps.setString(2, airline);
			ps.setString(3, classs);
			ps.setDouble(4, price);
			ps.setInt(5, numpass);
			int i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("\n Booking details inserted...\n");
			} else {
				System.out.println("\n Booking details not inserted...\n");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
		
