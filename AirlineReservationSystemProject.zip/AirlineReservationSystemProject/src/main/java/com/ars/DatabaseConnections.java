package com.ars;

import java.sql.Connection;
import java.sql.DriverManager;
/**
* Data base connection class-> it makes a connection in mysql
*1. Driver->That implements the java databases connectivity (JDBC) 
*2. url->data base management system JDBC driver uses to connect to a database
*3. forname()-> method is loading the driver dynamically loads a java class at runtime
*4. DriverManger->Is that class making connection to database by passing
*/


public class DatabaseConnections {

	private static String driver="com.mysql.cj.jdbc.Driver";
	private static String un="root";
	private static String pass="root";
	private static String url="jdbc:mysql://localhost:3306/userreserve";
	static Connection conn=null;
	public static Connection getConnection() {
	
	try {
		Class.forName(driver);
		
		conn=DriverManager.getConnection(url,un,pass);
		if(conn!=null) {
			return conn;
		}
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return conn;
	}

	}


